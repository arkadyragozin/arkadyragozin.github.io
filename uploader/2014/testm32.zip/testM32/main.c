#include <iom32.h>
#include <inavr.h>
#include "main.h"
#include "USART.h"
#include "DS1Wire.h"
#include "Util.h"
#include "bin_defines.h"

#define MAX_DEVICES  4      // ������������ ���������� ��������� �� ���� 1-Wire

D1W_device devices[MAX_DEVICES];

//unsigned char prepare_temper_pack(D1W_device* device);
unsigned char  test1 (void);


__task main( void ){
  unsigned char i, j;
  __watchdog_reset();
  WDTCR |= (1<<WDTOE) | (1<<WDE);
  WDTCR = 0x00;

  ACSR |= (1<<ACD); //�������� ���������� ����������
  __enable_interrupt();
  USART_Init( 21 );  // 115200 ��� ������ 20 ���

  D1W_Init();
  __delay_cycles(100 MS);
  
  
  
  
  while (1){  //�������� ����
    
    if (DS1W_SearchBuses(devices, MAX_DEVICES)==SEARCH_SUCCESSFUL){
      for(i=0;i<4;i++){
        for(j=0;j<8;j++){
          USART_Transmit(hex_to_ascii(devices[i].id[j]>>4));
          USART_Transmit(hex_to_ascii(devices[i].id[j]));
          USART_Transmit(' ');
        }
        USART_Transmit('\n');
        USART_Transmit('\r');
      }
      USART_sendstr("\n\rok!\n\r");
      DDRD &= ~LED7;
      __delay_cycles(100 MS);
      DDRD |=  LED7;
    }
    test1();
    
    __delay_cycles(1000 MS);
  }
}

unsigned char  test1 (void){
  unsigned char tmp;
  unsigned short i;
 /* 
  if(!D1W_DetectPresence()){
    DDRD |=  LED8;
    return 0; // Error
  }
  USART_sendstr("\n\rReadRom\n\r");
  D1W_SendByte(0x33);//ReadRom
  for (i = 0; i < 8; i++){
    tmp = D1W_ReceiveByte();
    USART_Transmit(hex_to_ascii(tmp>>4));
    USART_Transmit(hex_to_ascii(tmp));
    USART_Transmit(' ');
  }
  USART_sendstr("\n\rReadRom ok!\n\r");
*/
  
  if(!D1W_DetectPresence()){
    DDRD |=  LED8;
    return 0; // Error
  }
  USART_sendstr("\n\rSkipRom\n\r");
  D1W_SkipRom();
  D1W_SendByte(DS2433_READ_MEMORY);
  D1W_SendByte(0x00);
  D1W_SendByte(0x00);
  
  for (i = 0; i < 0x200; i++){
    tmp = D1W_ReceiveByte();
    USART_Transmit(hex_to_ascii(tmp>>4));
    USART_Transmit(hex_to_ascii(tmp));
    USART_Transmit(' ');
  }
  USART_sendstr("\n\rSkipRom ok!\n\r");
  __delay_cycles(100 MS);

  return 0;
}


