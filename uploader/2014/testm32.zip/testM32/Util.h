
unsigned char ansi2unicode(unsigned char a);
unsigned char unicode2ansi(unsigned char a,unsigned char b);
unsigned char is_hex_digit(unsigned char c);
unsigned char ascii2hex(unsigned char lo,unsigned char hi);
unsigned char ascii_to_hex(unsigned char c);
unsigned char hex2ascii(unsigned char hex);
unsigned char hex_to_ascii(unsigned char c);
unsigned char write_ascii(unsigned char c);
unsigned int GetCRC(unsigned int CRC,unsigned char b);
unsigned int GetBlockCRC(unsigned char* b,long len);
extern unsigned char *float_conversion(      float value,
                                             short nr_of_digits,
                                     unsigned char *buf,
                                     unsigned char format_flag,
                                     unsigned char g_flag,
                                     unsigned char alternate_flag);

unsigned char Str_to_byte(unsigned char *buf);
unsigned char Num_to_str(char *buf,unsigned char ln,unsigned long ul,unsigned char base);
unsigned long Str_to_num(unsigned char *buf, unsigned char base);
void Right_align_str(unsigned char *buf, int buf_len);
unsigned short hex2bcd (unsigned char hex);
